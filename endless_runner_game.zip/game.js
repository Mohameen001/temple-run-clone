const canvas = document.getElementById('gameCanvas');
const ctx = canvas.getContext('2d');

let player = { x: 175, y: 500, width: 50, height: 50, speed: 5 };
let obstacles = [];
let score = 0;
let gameOver = false;

// Create obstacles
function createObstacle() {
    const width = Math.random() * 100 + 20;
    const x = Math.random() * (canvas.width - width);
    obstacles.push({ x: x, y: -20, width: width, height: 20, speed: 3 });
}

// Update game state
function updateGame() {
    if (gameOver) return;

    // Clear canvas
    ctx.clearRect(0, 0, canvas.width, canvas.height);

    // Draw player
    ctx.fillStyle = 'blue';
    ctx.fillRect(player.x, player.y, player.width, player.height);

    // Update and draw obstacles
    ctx.fillStyle = 'red';
    for (let i = obstacles.length - 1; i >= 0; i--) {
        const obstacle = obstacles[i];
        obstacle.y += obstacle.speed;

        // Check for collision
        if (
            player.x < obstacle.x + obstacle.width &&
            player.x + player.width > obstacle.x &&
            player.y < obstacle.y + obstacle.height &&
            player.y + player.height > obstacle.y
        ) {
            gameOver = true;
            alert('Game Over! Your score: ' + score);
            return;
        }

        // Remove obstacles that have moved off screen
        if (obstacle.y > canvas.height) {
            obstacles.splice(i, 1);
            score++;
        } else {
            ctx.fillRect(obstacle.x, obstacle.y, obstacle.width, obstacle.height);
        }
    }

    // Create new obstacles
    if (Math.random() < 0.02) createObstacle();

    // Display score
    ctx.fillStyle = 'black';
    ctx.font = '20px Arial';
    ctx.fillText('Score: ' + score, 10, 30);

    requestAnimationFrame(updateGame);
}

// Handle keyboard input
document.addEventListener('keydown', (e) => {
    if (e.key === 'ArrowLeft' && player.x > 0) {
        player.x -= player.speed;
    } else if (e.key === 'ArrowRight' && player.x + player.width < canvas.width) {
        player.x += player.speed;
    }
});

// Start game
updateGame();